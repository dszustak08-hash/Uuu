package pl.wyrownywacz

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import android.os.SystemClock
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.sqrt

/**
 * Mierzy głośność dźwięku z systemu i steruje głośnością multimediów tak, żeby
 * to, co słyszysz, miało stały poziom docelowy. Sufitem jest głośność z chwili włączenia.
 * Ściszanie jest szybkie (wybuch), podgłaśnianie wolne (bez skakania).
 */
class LevelerService : Service() {

    @Volatile private var running = false
    private var proj: MediaProjection? = null
    private var rec: AudioRecord? = null

    override fun onBind(i: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (running || data == null) return START_NOT_STICKY

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("lvl", "Wyrównywacz", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, "lvl")
            .setContentTitle("Wyrównywacz głośności działa")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()
        startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(i.getIntExtra("code", 0), data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, null)
        }
        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        rec = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(16384)
            .build()

        running = true
        State.running = true
        State.status = "Czekam na dźwięk"
        Thread { loop() }.start()
        return START_NOT_STICKY
    }

    private fun outputDevice(am: AudioManager): Int {
        val types = am.getDevices(AudioManager.GET_DEVICES_OUTPUTS).map { it.type }
        for (t in listOf(AudioDeviceInfo.TYPE_BLUETOOTH_A2DP, AudioDeviceInfo.TYPE_WIRED_HEADPHONES,
            AudioDeviceInfo.TYPE_WIRED_HEADSET, AudioDeviceInfo.TYPE_USB_HEADSET)) if (t in types) return t
        return AudioDeviceInfo.TYPE_BUILTIN_SPEAKER
    }

    private fun loop() {
        val am = getSystemService(AudioManager::class.java)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val st = AudioManager.STREAM_MUSIC
        val ceil = am.getStreamVolume(st)            // sufit = głośność z chwili włączenia
        if (ceil < 3) { State.status = "Zwiększ głośność telefonu i włącz ponownie"; stopSelf(); return }
        State.ceiling = ceil

        // prawdziwa krzywa głośności telefonu w dB (z zapasowym przybliżeniem 3 dB na stopień)
        val dev = outputDevice(am)
        val vdb = DoubleArray(ceil + 1) { i ->
            try { am.getStreamVolumeDb(st, i, dev).toDouble() } catch (e: Exception) { (i - ceil) * 3.0 }
        }
        fun v(i: Int) = vdb[i.coerceIn(0, ceil)] - vdb[ceil]   // 0 dB = sufit, niżej ujemne

        var lastChange = 0L
        fun setVol(i: Int) { am.setStreamVolume(st, i.coerceIn(1, ceil), 0); lastChange = SystemClock.elapsedRealtime() }

        val buf = ShortArray(2205)                    // ok. 50 ms dźwięku
        // k = 1, gdy przechwycony dźwięk zależy od głośności telefonu; 0, gdy nie (ustala kalibracja)
        var k = -1; var phase = 0; var cnt = 0; var sum = 0.0; var m0 = 0.0
        var orig = ceil; var probe = ceil; var tWait = 0L
        var slow = Double.NaN; var fast = Double.NaN; var quiet = 0; var learn = 20

        rec?.startRecording()
        while (running) {
            val r = rec?.read(buf, 0, buf.size) ?: break
            if (r <= 0) continue
            var s2 = 0.0
            for (j in 0 until r) { val x = buf[j] / 32768.0; s2 += x * x }
            val rms = sqrt(s2 / r)
            val now = SystemClock.elapsedRealtime()
            val cur = am.getStreamVolume(st)
            State.index = cur

            if (rms < 0.003) {                        // cisza
                if (++quiet == 10) learn = 20          // ok. 0,5 s ciszy = nowy film, szybkie uczenie
                State.status = "Czekam na dźwięk"
                continue
            }
            quiet = 0
            val mDb = 20 * log10(rms)

            if (k < 0) {                              // kalibracja: czy telefon "słyszy" zmianę głośności
                State.status = "Kalibracja…"
                when (phase) {
                    0 -> { sum += mDb; cnt++
                        if (cnt >= 20) {
                            m0 = sum / cnt; orig = cur; probe = (cur - 4).coerceAtLeast(1)
                            if (v(orig) - v(probe) < 3.0) k = 1 else { setVol(probe); phase = 1; tWait = now }
                        } }
                    1 -> if (now - tWait > 300) { phase = 2; sum = 0.0; cnt = 0 }
                    else -> { sum += mDb; cnt++
                        if (cnt >= 10) {
                            val ratio = (sum / cnt - m0) / (v(probe) - v(orig))
                            k = if (ratio > 0.5) 1 else 0
                            setVol(orig)
                        } }
                }
                continue
            }

            val settling = now - lastChange < 250     // chwilę po zmianie głośności nie ufamy pomiarowi
            val s = mDb - v(cur) * k                  // poziom źródła przy suficie, niezależny od głośności telefonu
            if (!settling) {
                val a = if (learn > 0) 0.25 else 0.04
                if (learn > 0) learn--
                slow = if (slow.isNaN()) s else slow + a * (s - slow)
                fast = if (fast.isNaN()) s else fast + 0.5 * (s - fast)
            }
            if (slow.isNaN()) continue

            val eff = maxOf(slow, fast - 4)           // wybuch liczy się od razu, potem wraca powoli
            val target = -56 + 0.36 * prefs.getInt("target", 50)
            val need = target - eff                   // ile dB względem sufitu potrzeba

            var want = cur; var best = Double.MAX_VALUE
            for (i in 1..ceil) { val e = abs(v(i) - need); if (e < best) { best = e; want = i } }
            if (abs(v(cur) - need) < best + 1.0) want = cur   // histereza 1 dB, żeby nie skakało

            if (want < cur && now - lastChange > 80) {
                val dn = if (cur - want >= 3) 2 else 1
                setVol(cur - dn)                      // ściszanie: szybko
            } else if (want > cur && now - lastChange > 700) {
                setVol(cur + 1)                       // podgłaśnianie: wolno, po jednym stopniu
            }

            State.outDb = (fast + v(cur)).toFloat()
            State.targetDb = target.toFloat()
            State.status = "Wyrównuję"
        }
    }

    override fun onDestroy() {
        running = false
        State.running = false
        State.status = "Wyłączone"
        State.outDb = -90f
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release()
        proj?.stop()
        super.onDestroy()
    }
}
