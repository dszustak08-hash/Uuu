package pl.wyrownywacz

import android.annotation.SuppressLint
import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.*
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.IBinder
import kotlin.math.abs
import kotlin.math.log10
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sqrt

/**
 * Słucha dźwięku odtwarzanego w systemie (np. TikTok), mierzy jego głośność
 * i dokręca głośność multimediów tak, żeby wszystko brzmiało podobnie.
 */
class LevelerService : Service() {

    // Ile dB zmienia jeden stopień głośności telefonu. Jeśli korekta jest za słaba/za mocna, zmień.
    private val stepDb = 3.0

    @Volatile private var running = false
    private var proj: MediaProjection? = null
    private var rec: AudioRecord? = null

    override fun onBind(i: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        @Suppress("DEPRECATION") val data = i?.getParcelableExtra<Intent>("data")
        if (running || data == null) return START_NOT_STICKY

        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("lvl", "Wyrównywacz", NotificationManager.IMPORTANCE_LOW))
        val note = Notification.Builder(this, "lvl")
            .setContentTitle("Wyrównywacz głośności działa")
            .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
            .build()
        startForeground(1, note, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)

        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        proj = mpm.getMediaProjection(i.getIntExtra("code", 0), data).also {
            it.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, null)
        }

        val cfg = AudioPlaybackCaptureConfiguration.Builder(proj!!)
            .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
            .addMatchingUsage(AudioAttributes.USAGE_GAME)
            .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
            .build()
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(44100)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        rec = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setAudioPlaybackCaptureConfig(cfg)
            .setBufferSizeInBytes(16384)
            .build()

        running = true
        Thread { loop() }.start()
        return START_NOT_STICKY
    }

    private fun loop() {
        val am = getSystemService(AudioManager::class.java)
        val prefs = getSharedPreferences("p", MODE_PRIVATE)
        val stream = AudioManager.STREAM_MUSIC
        val max = am.getStreamMaxVolume(stream)
        val base = am.getStreamVolume(stream)   // głośność wybrana przez Ciebie przy włączeniu
        val buf = ShortArray(2205)               // ok. 50 ms dźwięku
        var avg = 0.0; var n = 0; var quiet = 0; var last = 0L

        rec?.startRecording()
        while (running) {
            val r = rec?.read(buf, 0, buf.size) ?: break
            if (r <= 0) continue
            var s = 0.0
            for (k in 0 until r) { val x = buf[k] / 32768.0; s += x * x }
            val rms = sqrt(s / r)

            if (rms < 0.003) {                   // cisza
                if (++quiet > 6) { avg = 0.0; n = 0 }   // ~0,3 s ciszy = zaczął się nowy film
                continue
            }
            quiet = 0
            val a = if (n < 20) 0.25 else 0.04   // na początku filmu uczy się szybko
            avg = if (avg == 0.0) rms else avg + a * (rms - avg)
            n++

            val targetDb = -40 + 0.28 * prefs.getInt("target", 50)
            val diffDb = targetDb - 20 * log10(avg)
            val want = (base + (diffDb / stepDb).roundToInt()).coerceIn(1, max)
            val cur = am.getStreamVolume(stream)
            val now = System.currentTimeMillis()
            if (want != cur && now - last > 400) {
                am.setStreamVolume(stream, cur + sign((want - cur).toDouble()).toInt(), 0) // 0 = bez paska głośności
                last = now
            }
        }
    }

    override fun onDestroy() {
        running = false
        try { rec?.stop() } catch (_: Exception) {}
        rec?.release()
        proj?.stop()
        super.onDestroy()
    }
}
