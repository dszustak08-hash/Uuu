package pl.wyrownywacz

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.widget.*

class MainActivity : Activity() {

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val info = TextView(this).apply {
            text = "1. Ustaw głośność telefonu na wygodną.\n2. Kliknij Włącz i zezwól na przechwytywanie.\n3. Otwórz TikToka. Suwakiem koryguj ogólny poziom."
            textSize = 15f
        }
        val label = TextView(this).apply { textSize = 18f; setPadding(0, pad, 0, 0) }
        val bar = SeekBar(this).apply { max = 100; progress = prefs.getInt("target", 50) }
        fun refresh() {
            label.text = "Docelowa głośność: ${bar.progress}%"
            prefs.edit().putInt("target", bar.progress).apply()
        }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = refresh()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        refresh()

        val start = Button(this).apply {
            text = "Włącz"
            setOnClickListener {
                requestPermissions(
                    arrayOf(android.Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 2
                )
            }
        }
        val stop = Button(this).apply {
            text = "Wyłącz"
            setOnClickListener { stopService(Intent(this@MainActivity, LevelerService::class.java)) }
        }

        setContentView(LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad * 2, pad, pad)
            addView(info); addView(label); addView(bar); addView(start); addView(stop)
        })
    }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, LevelerService::class.java).putExtra("code", res).putExtra("data", data)
            )
        }
    }
}
