package pl.wyrownywacz

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.media.AudioManager
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*

/** Stan współdzielony między usługą a ekranem. */
object State {
    @Volatile var running = false
    @Volatile var status = "Wyłączone"
    @Volatile var outDb = -90f      // poziom, który słyszysz (dB względem Twojego sufitu głośności)
    @Volatile var targetDb = -40f   // poziom docelowy z suwaka
    @Volatile var index = 0
    @Volatile var ceiling = 0
}

/** Wykres ostatnich ~20 s: niebieska linia = co słyszysz, żółta przerywana = cel. */
class GraphView(c: Context) : View(c) {
    private val n = 200
    private val lvl = FloatArray(n) { -90f }
    private val tgt = FloatArray(n) { -90f }
    private val bg = Paint().apply { color = 0xFF17262F.toInt() }
    private val pOut = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF3CC4CF.toInt(); style = Paint.Style.STROKE; strokeWidth = 6f
    }
    private val pTgt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFF2B632.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
        pathEffect = DashPathEffect(floatArrayOf(16f, 12f), 0f)
    }

    fun push(o: Float, t: Float) {
        System.arraycopy(lvl, 1, lvl, 0, n - 1); lvl[n - 1] = o
        System.arraycopy(tgt, 1, tgt, 0, n - 1); tgt[n - 1] = t
        invalidate()
    }

    private fun line(a: FloatArray, w: Float, h: Float): Path {
        val p = Path()
        for (i in 0 until n) {
            val x = i / (n - 1f) * w
            val y = h - 14f - (a[i].coerceIn(-60f, 0f) + 60f) / 60f * (h - 28f)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        return p
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        c.drawRoundRect(0f, 0f, w, h, 28f, 28f, bg)
        c.drawPath(line(tgt, w, h), pTgt)
        c.drawPath(line(lvl, w, h), pOut)
    }
}

class MainActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private lateinit var status: TextView
    private lateinit var vol: TextView
    private lateinit var btn: Button
    private lateinit var graph: GraphView

    private val tick = object : Runnable {
        override fun run() {
            val am = getSystemService(AudioManager::class.java)
            status.text = State.status
            vol.text = "Głośność telefonu: ${am.getStreamVolume(AudioManager.STREAM_MUSIC)} / ${State.ceiling.coerceAtLeast(am.getStreamVolume(AudioManager.STREAM_MUSIC))} (sufit)"
            btn.text = if (State.running) "Wyłącz" else "Włącz"
            graph.push(State.outDb, State.targetDb)
            h.postDelayed(this, 100)
        }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val prefs = getSharedPreferences("p", Context.MODE_PRIVATE)
        val d = resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()
        fun tv(t: String, sp: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
            text = t; textSize = sp; setTextColor(color); if (bold) setTypeface(null, Typeface.BOLD)
        }
        val white = 0xFFE6EEF3.toInt(); val grey = 0xFF8FA3B1.toInt()

        status = tv("Wyłączone", 16f, 0xFF3CC4CF.toInt(), true)
        graph = GraphView(this)
        vol = tv("", 14f, grey)
        val pct = tv("", 18f, white, true)
        val bar = SeekBar(this).apply { max = 100; progress = prefs.getInt("target", 50) }
        fun upd() { pct.text = "Docelowa głośność: ${bar.progress}%"; prefs.edit().putInt("target", bar.progress).apply() }
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, u: Boolean) = upd()
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        upd()

        btn = Button(this).apply {
            textSize = 18f; isAllCaps = false; setTextColor(0xFF06222A.toInt())
            background = GradientDrawable().apply { setColor(0xFF3CC4CF.toInt()); cornerRadius = dp(14).toFloat() }
            setOnClickListener {
                if (State.running) stopService(Intent(this@MainActivity, LevelerService::class.java))
                else requestPermissions(arrayOf(android.Manifest.permission.RECORD_AUDIO, "android.permission.POST_NOTIFICATIONS"), 2)
            }
        }
        val hint = tv(
            "Ustaw głośność telefonu na największą, jaką chcesz mieć (to jest sufit), i dopiero kliknij Włącz. " +
            "Na początku usłyszysz krótkie ściszenie, to kalibracja. Niebieska linia to to, co słyszysz, żółta to cel.",
            13f, grey
        )

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xFF0F1A22.toInt())
            setPadding(dp(20), dp(44), dp(20), dp(24))
            addView(tv("Wyrównywacz głośności", 24f, white, true))
            addView(status)
            addView(graph, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(170)).apply { topMargin = dp(14) })
            addView(vol, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(10) })
            addView(pct, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(18) })
            addView(bar)
            addView(btn, LinearLayout.LayoutParams(-1, dp(56)).apply { topMargin = dp(22) })
            addView(hint, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(16) })
        }
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFF0F1A22.toInt()); addView(root) })
    }

    override fun onResume() { super.onResume(); h.post(tick) }
    override fun onPause() { super.onPause(); h.removeCallbacks(tick) }

    override fun onRequestPermissionsResult(code: Int, p: Array<out String>, r: IntArray) {
        super.onRequestPermissionsResult(code, p, r)
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), 1)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 1 && res == RESULT_OK && data != null) {
            startForegroundService(
                Intent(this, LevelerService::class.java).putExtra("code", res).putExtra("data", data)
            )
        }
    }
}
