plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "pl.wyrownywacz"
    compileSdk = 34
    defaultConfig {
        applicationId = "pl.wyrownywacz"
        minSdk = 29          // przechwytywanie dźwięku systemu działa od Androida 10
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
